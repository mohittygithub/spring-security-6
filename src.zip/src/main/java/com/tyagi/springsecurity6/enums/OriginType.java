package com.tyagi.springsecurity6.enums;

public enum OriginType {
    HAND_MADE,
    FACTORY_MADE
}
